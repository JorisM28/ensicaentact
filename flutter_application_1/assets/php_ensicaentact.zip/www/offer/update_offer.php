<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = null;

if (isset($headers['X-Authorization'])) {
    $authHeader = $headers['X-Authorization'];
} 
elseif (isset($_SERVER['HTTP_X_AUTHORIZATION'])) {
    $authHeader = $_SERVER['HTTP_X_AUTHORIZATION'];
}
elseif (isset($headers['Authorization'])) {
    $authHeader = $headers['Authorization'];
} 
elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
} 
elseif (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
}

$token = null;
if ($authHeader) {
    if (preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        $token = $matches[1];
    } else {
        $token = $authHeader;
    }
}

require_once "../jwt_utils.php"; 
$userData = null;
try {
    if(function_exists('verifyJWT')) {
        $userData = verifyJWT($token);
    }
} catch (Exception $e) { }

if (!$userData || (isset($userData['role']) && $userData['role'] !== 'admin')) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Accès refusé. Token invalide ou manquant.", "debug_token_recu" => $token]);
    exit();
}
require_once dirname(__DIR__) . '/db.php';

$data = json_decode(file_get_contents("php://input"));

if(!empty($data->id_offre) && !empty($data->titre)){
    try {
        $query = "UPDATE OFFRES 
                  SET titre = :t, entreprise = :e, ville = :v, type = :ty, description = :d, contact_email = :em
                  WHERE id_offre = :id";
        
        $stmt = $pdo->prepare($query);
        $success = $stmt->execute([
            ":t"  => $data->titre,
            ":e"  => $data->entreprise,
            ":v"  => $data->ville ?? "",
            ":ty" => $data->type,
            ":d"  => $data->description ?? "",
            ":em" => $data->contact_email ?? "",
            ":id" => $data->id_offre
        ]);

        echo json_encode(["status" => $success ? "success" : "error"]);
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Données manquantes"]);
}
?>
