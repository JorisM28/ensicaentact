<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = null;

if (isset($headers['X-Authorization'])) {
    $authHeader = $headers['X-Authorization'];
} 
elseif (isset($_SERVER['HTTP_X_AUTHORIZATION'])) {
    $authHeader = $_SERVER['HTTP_X_AUTHORIZATION'];
}
elseif (isset($headers['Authorization'])) {
    $authHeader = $headers['Authorization'];
} 
elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
} 
elseif (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
}

$token = null;
if ($authHeader) {
    if (preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        $token = $matches[1];
    } else {
        $token = $authHeader;
    }
}

require_once "../jwt_utils.php"; 
$userData = null;
try {
    if(function_exists('verifyJWT')) {
        $userData = verifyJWT($token);
    }
} catch (Exception $e) { }

if (!$userData || !isset($userData['role'])) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Accès refusé. Token invalide ou manquant."]);
    exit();
}

require_once dirname(__DIR__) . '/db.php';

$data = json_decode(file_get_contents("php://input"));

if(!empty($data->titre) && !empty($data->entreprise)){
    try {
        $id_auteur = $data->id_auteur;
        $check = $pdo->prepare("SELECT id_user FROM UTILISATEUR WHERE id_user = ?");
        $check->execute([$id_auteur]);

        if ($check->rowCount() == 0) {
            $id_auteur = 2; 
        }

        $query = "INSERT INTO OFFRES (titre, entreprise, ville, type, description, contact_email, date_ajout, id_auteur) 
                  VALUES (:titre, :entreprise, :ville, :type, :desc, :email, NOW(), :id_auteur)";
        
        $stmt = $pdo->prepare($query);
        
        $success = $stmt->execute([
            ':titre'      => $data->titre,
            ':entreprise' => $data->entreprise,
            ':ville'      => $data->ville ?? "",
            ':type'       => $data->type ?? "CDI",
            ':desc'       => $data->description ?? "",
            ':email'      => $data->contact_email ?? "",
            ':id_auteur'  => $id_auteur
        ]);

        if($success) {
            echo json_encode(["status" => "success", "message" => "Offre ajoutée (ID Auteur: $id_auteur)"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Echec de l'ajout SQL"]);
        }

    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Erreur SQL: " . $e->getMessage()]);
    }
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Données incomplètes"]);
}
?>
