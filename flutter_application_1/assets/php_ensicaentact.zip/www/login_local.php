<?php
ini_set('display_errors', 0);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'db.php';
require_once 'jwt_utils.php'; 

$json = file_get_contents("php://input");
$data = json_decode($json, true);

$email_envoye = $data['email'] ?? $_POST['email'] ?? '';
$pass_envoye  = $data['password'] ?? $_POST['password'] ?? '';

if(empty($email_envoye) || empty($pass_envoye)){
    echo json_encode(["status" => "error", "message" => "Email ou mot de passe manquant"]);
    exit();
}

$stmt = $pdo->prepare("
    SELECT u.id_user, u.nom, u.prenom, u.email, u.password, u.role, a.tel 
    FROM UTILISATEUR u 
    LEFT JOIN ALUMNI a ON u.id_user = a.id_user 
    WHERE u.email = :email LIMIT 1
");
$stmt->execute(['email' => $email_envoye]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {

    if (password_verify($pass_envoye, $user['password'])) {
        
        $role = !empty($user['role']) ? $user['role'] : 'student';
        $token = generateJWT($user['id_user'], $role);

        echo json_encode([
            "status"      => "success",
            "message"     => "Connexion réussie",
            "token"       => $token, 
            "id"          => $user['id_user'],
            "role"        => $role,
            "name"        => $user['prenom'],
            "family_name" => $user['nom'],
            "email"       => $user['email'],
            "phone"       => $user['tel'] ?? ""
        ]);

    } else {
        http_response_code(401);
        echo json_encode(["status" => "error", "message" => "Mot de passe incorrect"]);
    }
} else {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Utilisateur non trouvé"]);
}
