<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = $headers['X-Authorization'] ?? $_SERVER['HTTP_X_AUTHORIZATION'] ?? $headers['Authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? null;

$token = null;
if ($authHeader && preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    $token = $matches[1];
} elseif ($authHeader) {
    $token = $authHeader;
}

require_once "../jwt_utils.php"; 
$userData = null;
try {
    if(function_exists('verifyJWT')) $userData = verifyJWT($token);
} catch (Exception $e) { }

require_once "../db.php";

try {
    $sql = "SELECT a.*, u.nom as nom_auteur, u.prenom as prenom_auteur 
            FROM ACTUALITES a 
            LEFT JOIN UTILISATEUR u ON a.id_auteur = u.id_user 
            ORDER BY a.date_publi DESC";

    $stmt = $pdo->query($sql);
    $actualites = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($actualites);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Erreur SQL : " . $e->getMessage()]);
}
?>
