<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

if (file_exists("../db.php")) {
    require_once "../db.php";
} elseif (file_exists("db.php")) {
    require_once "db.php";
} else {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Fichier db.php introuvable."]);
    exit();
}

$data = json_decode(file_get_contents("php://input"));
file_put_contents('debug_post.txt', print_r($data, true));


if(
    !empty($data->titre) && 
    !empty($data->description) 
){
    $titre = htmlspecialchars(strip_tags($data->titre)); 
    $contenu = htmlspecialchars(strip_tags($data->description)); 
    $image_url = isset($data->image) ? $data->image : "";
    
    $id_recu = (isset($data->auteur_id)) ? $data->auteur_id : "0";

    $id_fallback = 2; 

    if (empty($id_recu) || $id_recu == "0" || $id_recu == 0) {
        $id_auteur = $id_fallback;
    } else {
        $id_auteur = $id_recu;
    }
    
    $tag = "NEWS";
    $tag_color = "#00a1a1"; 

    try {
        $query = "INSERT INTO ACTUALITES 
                  (titre, contenu, date_publi, image_url, id_auteur, tag, tag_color) 
                  VALUES 
                  (:titre, :contenu, NOW(), :image_url, :id_auteur, :tag, :tag_color)";

        $stmt = $pdo->prepare($query);

        $stmt->bindParam(":titre", $titre);
        $stmt->bindParam(":contenu", $contenu);
        $stmt->bindParam(":image_url", $image_url);
        $stmt->bindParam(":id_auteur", $id_auteur);
        $stmt->bindParam(":tag", $tag);
        $stmt->bindParam(":tag_color", $tag_color);

        if($stmt->execute()){
            http_response_code(200);
            echo json_encode(array("status" => "success", "message" => "Article créé avec succès (Auteur ID: $id_auteur)."));
        } else {
            throw new Exception("Erreur SQL lors de l'exécution.");
        }

    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(array("status" => "error", "message" => "Erreur SQL : " . $e->getMessage()));
    }

} else {
    http_response_code(400);
    echo json_encode(array("status" => "error", "message" => "Titre ou description manquant."));
}
?>
