<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = $headers['X-Authorization'] ?? $_SERVER['HTTP_X_AUTHORIZATION'] ?? $headers['Authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? null;

$token = null;
if ($authHeader && preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    $token = $matches[1];
} elseif ($authHeader) {
    $token = $authHeader;
}

require_once "../jwt_utils.php"; 
$userData = null;
try {
    if(function_exists('verifyJWT')) $userData = verifyJWT($token);
} catch (Exception $e) { }

if (!$userData || (isset($userData['role']) && $userData['role'] !== 'admin')) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Accès refusé. Privilèges administrateur requis."]);
    exit();
}

require_once "../db.php";

$json = file_get_contents("php://input");
$data = json_decode($json);

if (!empty($data->id_demande)) {
    try {
        $stmt = $pdo->prepare("DELETE FROM DEMANDE_AJOUT WHERE id_demande = ?");
        $stmt->execute([$data->id_demande]);

        if ($stmt->rowCount() > 0) {
            echo json_encode(["status" => "success", "message" => "Demande supprimée"]);
        } else {
            echo json_encode(["status" => "success", "message" => "Aucune demande trouvée, mais considérée comme supprimée"]);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Erreur SQL: " . $e->getMessage()]);
    }
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "ID manquant"]);
}
?>
