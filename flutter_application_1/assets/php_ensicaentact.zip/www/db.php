<?php
$config_path = __DIR__ . '/config_db.ini';

if (!file_exists($config_path)) {
    die(json_encode(["error" => "Erreur de configuration serveur"]));
}

$config = parse_ini_file($config_path);

if (!$config) {
    die(json_encode(["error" => "Erreur de lecture de la configuration"]));
}

$host = $config['host'];
$db_name = $config['db_name'];
$username = $config['username'];
$password = $config['password'];

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(["error" => "Erreur de connexion à la base de données"]));
}
?>
