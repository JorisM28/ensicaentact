<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = $headers['X-Authorization'] ?? $_SERVER['HTTP_X_AUTHORIZATION'] ?? $headers['Authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? null;

$token = null;
if ($authHeader && preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    $token = $matches[1];
} elseif ($authHeader) {
    $token = $authHeader;
}

require_once "jwt_utils.php"; 
$userData = null;
try {
    if(function_exists('verifyJWT')) $userData = verifyJWT($token);
} catch (Exception $e) { }

if (!$userData)) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Accès refusé. Privilèges administrateur requis."]);
    exit();
}
require_once 'db.php';

$email   = $_POST['email'] ?? '';
$oldPass = $_POST['old_password'] ?? '';
$newPass = $_POST['new_password'] ?? '';

if(empty($email) || empty($oldPass) || empty($newPass)) {
    echo json_encode(["status" => "error", "message" => "Champs manquants"]);
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM UTILISATEUR WHERE email = :email LIMIT 1");
$stmt->execute(['email' => $email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    if (password_verify($oldPass, $user['password'])) {
        $hash = password_hash($newPass, PASSWORD_DEFAULT);
	$update = $pdo->prepare("UPDATE UTILISATEUR SET password = :new_pass WHERE email = :email");
        
        $result = $update->execute([
            'new_pass' => $hash,
            'email'    => $email
        ]);
        
        if ($result) {
            echo json_encode(["status" => "success", "message" => "Mot de passe modifié avec succès"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Erreur lors de la mise à jour BDD"]);
        }

    } else {
        echo json_encode(["status" => "error", "message" => "L'ancien mot de passe est incorrect"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Utilisateur introuvable"]);
}
?>
