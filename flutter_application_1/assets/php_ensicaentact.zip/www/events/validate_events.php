<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = null;

if (isset($headers['X-Authorization'])) {
    $authHeader = $headers['X-Authorization'];
} 
elseif (isset($_SERVER['HTTP_X_AUTHORIZATION'])) {
    $authHeader = $_SERVER['HTTP_X_AUTHORIZATION'];
}
elseif (isset($headers['Authorization'])) {
    $authHeader = $headers['Authorization'];
} 
elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
} 
elseif (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
}

$token = null;
if ($authHeader) {
    if (preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        $token = $matches[1];
    } else {
        $token = $authHeader;
    }
}

require_once "../jwt_utils.php"; 
$userData = null;
try {
    if(function_exists('verifyJWT')) {
        $userData = verifyJWT($token);
    }
} catch (Exception $e) { }

if (!$userData || (isset($userData['role']) && $userData['role'] !== 'admin')) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Accès refusé. Token invalide ou manquant.", "debug_token_recu" => $token]);
    exit();
}

require_once dirname(__DIR__) . '/db.php';
$data = json_decode(file_get_contents("php://input"));

if(!empty($data->id_demande)){
    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("SELECT contenu_json FROM DEMANDE_AJOUT WHERE id_demande = ?");
        $stmt->execute([$data->id_demande]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if($row){
            $eventDetails = json_decode($row['contenu_json'], true);

            $id_auteur = 2; 
            if (!empty($eventDetails['id_auteur']) && $eventDetails['id_auteur'] != 0) {
                $id_auteur = $eventDetails['id_auteur'];
            }

            $ins = $pdo->prepare("INSERT INTO EVENEMENTS (titre, lieu, description, date_event, id_auteur, date_creation, type) 
                                  VALUES (:titre, :lieu, :description, :date_event, :id_auteur, NOW(), :type)");
            
            $ins->execute([
                ":titre"       => $eventDetails['titre'],
                ":lieu"        => $eventDetails['lieu'] ?? "",
                ":description" => $eventDetails['description'] ?? "",
                ":date_event"  => $eventDetails['date_event'],
                ":id_auteur"   => $id_auteur,
                ":type"        => $eventDetails['type_event'] ?? 'Rencontre'
            ]);

            $del = $pdo->prepare("DELETE FROM DEMANDE_AJOUT WHERE id_demande = ?");
            $del->execute([$data->id_demande]);

            $pdo->commit();
            echo json_encode(["success" => true, "message" => "Évènement validé et publié !"]);
        } else {
            throw new Exception("Demande introuvable");
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(["success" => false, "error" => $e->getMessage()]);
    }
} else {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "ID demande manquant"]);
}
?>
