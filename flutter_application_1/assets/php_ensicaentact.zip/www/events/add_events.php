<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = null;

if (isset($headers['X-Authorization'])) {
    $authHeader = $headers['X-Authorization'];
} 
elseif (isset($_SERVER['HTTP_X_AUTHORIZATION'])) {
    $authHeader = $_SERVER['HTTP_X_AUTHORIZATION'];
}
elseif (isset($headers['Authorization'])) {
    $authHeader = $headers['Authorization'];
} 
elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
} 
elseif (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
}

$token = null;
if ($authHeader) {
    if (preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        $token = $matches[1];
    } else {
        $token = $authHeader;
    }
}

require_once "../jwt_utils.php"; 
$userData = null;
try {
    if(function_exists('verifyJWT')) {
        $userData = verifyJWT($token);
    }
} catch (Exception $e) { }

if (!$userData || (isset($userData['role']) && $userData['role'] !== 'admin')) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Accès refusé. Token invalide ou manquant.", "debug_token_recu" => $token]);
    exit();
}


require_once dirname(__DIR__) . '/db.php';

$data = json_decode(file_get_contents("php://input"));

if(!empty($data->titre) && !empty($data->date_event)){
    try {
        $id_auteur = (!empty($data->id_auteur) && $data->id_auteur != "0") ? $data->id_auteur : "2";

        $query = "INSERT INTO EVENEMENTS (titre, lieu, description, date_event, id_auteur, date_creation, type) 
                  VALUES (:titre, :lieu, :description, :date_event, :id_auteur, NOW(), :type)";
        
        $stmt = $pdo->prepare($query);
        
        $stmt->execute([
            ":titre"       => $data->titre,
            ":lieu"        => $data->lieu ?? "",
            ":description" => $data->description ?? "",
            ":date_event"  => $data->date_event,
            ":id_auteur"   => $id_auteur,
            ":type"        => "Rencontre"
        ]);

        echo json_encode(["success" => true, "message" => "Évènement ajouté (Auteur ID: $id_auteur)"]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Erreur SQL : " . $e->getMessage()]);
    }
} else {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Données incomplètes"]);
}
?>
