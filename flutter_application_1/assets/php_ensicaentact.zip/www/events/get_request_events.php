<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = $headers['X-Authorization'] ?? $_SERVER['HTTP_X_AUTHORIZATION'] ?? $headers['Authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? null;
$token = $authHeader ? (preg_match('/Bearer\s(\S+)/', $authHeader, $matches) ? $matches[1] : $authHeader) : null;


require_once "jwt_utils.php"; 
$userData = null;
try { if(function_exists('verifyJWT')) $userData = verifyJWT($token); } catch (Exception $e) { }

if (!$userData || (isset($userData['role']) && $userData['role'] !== 'admin')) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied."]);
    exit();
}

require_once dirname(__DIR__) . '/db.php';

try {
    $sql = "SELECT * FROM DEMANDE_AJOUT WHERE type = 'EVENEMENT' ORDER BY date_demande DESC";
    $stmt = $pdo->query($sql);
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $formatted_results = [];

    foreach ($requests as $row) {
        $details = json_decode($row['contenu_json'], true);

        $item = [
            'id_demande'  => $row['id_demande'],
            'date_demande'=> $row['date_demande'],
            'statuts'     => $row['statut'],
            'nom_auteur'  => $row['nom'],
            'prenom_auteur'=> $row['prenom'],
            'titre'       => $details['titre'] ?? "Sans titre",
            'lieu'        => $details['lieu'] ?? "",
            'description' => $details['description'] ?? "",
            'date_event'  => $details['date_event'] ?? "",
            'type'        => $details['type_event'] ?? "Rencontre"
        ];

        $formatted_results[] = $item;
    }

    echo json_encode($formatted_results);

} catch (Exception $e) {
    echo json_encode([]);
}
?>
