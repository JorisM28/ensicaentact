<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = $headers['X-Authorization'] ?? $_SERVER['HTTP_X_AUTHORIZATION'] ?? $headers['Authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? null;

$token = null;
if ($authHeader && preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    $token = $matches[1];
} elseif ($authHeader) {
    $token = $authHeader;
}

require_once "jwt_utils.php"; 
$userData = null;
try {
    if(function_exists('verifyJWT')) $userData = verifyJWT($token);
} catch (Exception $e) { }

if (!$userData || (isset($userData['role']) && $userData['role'] !== 'admin')) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Accès refusé. Privilèges administrateur requis."]);
    exit();
}

require_once 'db.php';

$json = file_get_contents("php://input");
$data = json_decode($json, true);


if (!is_array($data)) {
    echo json_encode(["status" => "error", "message" => "Format invalide : Données vides ou mal formées"]);
    exit();
}

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("UPDATE KEY_FIGURES SET
        label = :label,
        stat_value = :val,
        suffix = :suffix,
        icon_key = :icon,
        color_hex = :color
        WHERE id = :id");

    foreach ($data as $item) {
        $label = $item['label'] ?? '';
        $val   = $item['stat_value'] ?? 0;
        $suff  = $item['suffix'] ?? '';
        $icon  = $item['icon_key'] ?? 'school';
        $col   = $item['color_hex'] ?? '#000000';
        $id    = $item['id'];

        $stmt->execute([
            ':label'  => $label,
            ':val'    => $val,
            ':suffix' => $suff,
            ':icon'   => $icon,
            ':color'  => $col,
            ':id'     => $id
        ]);
    }

    $pdo->commit();
    echo json_encode(["status" => "success", "message" => "Mise à jour réussie"]);

} catch(Exception $e) {
   if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(["status" => "error", "message" => "Erreur SQL : " . $e->getMessage()]);
}
?>
