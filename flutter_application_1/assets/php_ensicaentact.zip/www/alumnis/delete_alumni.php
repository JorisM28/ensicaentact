<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = null;

if (isset($headers['X-Authorization'])) {
    $authHeader = $headers['X-Authorization'];
} 
elseif (isset($_SERVER['HTTP_X_AUTHORIZATION'])) {
    $authHeader = $_SERVER['HTTP_X_AUTHORIZATION'];
}
elseif (isset($headers['Authorization'])) {
    $authHeader = $headers['Authorization'];
} 
elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
} 
elseif (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
}

$token = null;
if ($authHeader) {
    if (preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        $token = $matches[1];
    } else {
        $token = $authHeader;
    }
}

require_once "../jwt_utils.php"; 
$userData = null;
try {
    if(function_exists('verifyJWT')) {
        $userData = verifyJWT($token);
    }
} catch (Exception $e) { }

if (!$userData || (isset($userData['role']) && $userData['role'] !== 'admin')) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Accès refusé. Token invalide ou manquant.", "debug_token_recu" => $token]);
    exit();
}

require_once "../db.php"; 

$data = json_decode(file_get_contents("php://input"));
$idEditeur = $userData['id'] ?? $userData['id_user'] ?? 0;

if(!empty($data->id)) {
     $id = $data->id;
     $stmtInfo = $pdo->prepare("SELECT nom, prenom FROM UTILISATEUR WHERE id_user = ?");
     $stmtInfo->execute([$id]);
     $info = $stmtInfo->fetch(PDO::FETCH_ASSOC);
     $nom = $info['nom'] ?? 'Inconnu';
     $prenom = $info['prenom'] ?? '';
} elseif(!empty($data->nom) && !empty($data->prenom)) {
    $stmt = $pdo->prepare("SELECT id_user, nom, prenom FROM UTILISATEUR WHERE nom=? AND prenom=?");
    $stmt->execute([$data->nom, $data->prenom]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if($user) {
        $id = $user['id_user'];
        $nom = $user['nom'];
        $prenom = $user['prenom'];
    } else {
        echo json_encode(["status" => "error", "message" => "Utilisateur introuvable."]);
        exit();
    }
} else {
    echo json_encode(["status" => "error", "message" => "Données manquantes."]);
    exit();
}

if (isset($id)) {
    try {
        $pdo->beginTransaction();

        $descriptionAction = "Suppression du profil de : $prenom $nom";

        $stmtLog = $pdo->prepare("INSERT INTO HISTORIQUE (id_editeur, id_alumni, action, description, date_action) VALUES (NULL, NULL, 'SUPPRESSION', ?, NOW())");
        $stmtLog->execute([$descriptionAction]);

        $pdo->prepare("DELETE FROM TRAVAIL WHERE id_user=?")->execute([$id]);
        $pdo->prepare("DELETE FROM EDUCATION WHERE id_user=?")->execute([$id]);
        $pdo->prepare("DELETE FROM STAGE WHERE id_user=?")->execute([$id]);
        
        $del = $pdo->prepare("DELETE FROM UTILISATEUR WHERE id_user=?");
        $del->execute([$id]);

        $pdo->commit();
        echo json_encode(["status" => "success", "message" => "Utilisateur supprimé avec succès."]);

    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Erreur SQL : " . $e->getMessage()]);
    }
}
?>
