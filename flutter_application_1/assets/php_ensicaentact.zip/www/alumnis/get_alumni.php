<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = null;

if (isset($headers['X-Authorization'])) {
    $authHeader = $headers['X-Authorization'];
} 
elseif (isset($_SERVER['HTTP_X_AUTHORIZATION'])) {
    $authHeader = $_SERVER['HTTP_X_AUTHORIZATION'];
}
elseif (isset($headers['Authorization'])) {
    $authHeader = $headers['Authorization'];
} 
elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
} 
elseif (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
    $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
}

$token = null;
if ($authHeader) {
    if (preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        $token = $matches[1];
    } else {
        $token = $authHeader;
    }
}

require_once "../jwt_utils.php"; 
$userData = null;
try {
    if(function_exists('verifyJWT')) {
        $userData = verifyJWT($token);
    }
} catch (Exception $e) { }

if (!$userData) {
    http_response_code(403);
    echo json_encode([
        "status" => "error", 
        "message" => "Accès refusé. Token invalide ou manquant.",
        "debug_token_recu" => $token
    ]);
    exit();
}

require_once "../db.php";

$sql = "SELECT 
            u.id_user AS id,
            u.nom, 
            u.prenom, 
            u.email,
            a.tel,
            a.autor,
            a.decede,
            a.sexe,
            a.date_naissance AS dateNaissance, 
            
            pr.promo,
            pr.filiere,
            pr.formation,
            
            e.majeure,
            e.option_ AS 'option',
            e.ddiplome AS diplome,
            
            t.poste AS job,
            t.description AS job_desc,
            t.date_debut AS job_debut,            
            l.entreprise, 
            l.ville,
            l.code_postal,
            l.pays,


            (
                SELECT JSON_ARRAYAGG(
                    JSON_OBJECT(
                        'annee', s.annee,
                        'intitule', s.intitule,
                        'description', IFNULL(s.description, ''),
                        'entrepriseUniversite', s.entrepriseUniversite,
                        'entreprise', IFNULL(ls.entreprise, ''),
                        'ville', IFNULL(ls.ville, ''),
                        'code_postal', IFNULL(ls.code_postal, ''),
                        'pays', IFNULL(ls.pays, ''),
                        'debut', IFNULL(s.date_debut, ''),
                        'fin', IFNULL(s.date_fin, '')
                    )
                )
                FROM STAGE s
                LEFT JOIN LIEU ls ON s.id_lieu = ls.id_lieu
                WHERE s.id_user = u.id_user
            ) AS stages_list

        FROM UTILISATEUR u
        LEFT JOIN ALUMNI a ON u.id_user = a.id_user
        LEFT JOIN EDUCATION e ON u.id_user = e.id_user
        LEFT JOIN PROMO pr ON e.id_promo = pr.id_promo
        LEFT JOIN TRAVAIL t ON u.id_user = t.id_user
        LEFT JOIN LIEU l ON t.id_lieu = l.id_lieu
        WHERE u.role = 'alumni'
        GROUP BY u.id_user
	ORDER BY u.nom ASC";

try {
    $stmt = $pdo->query($sql);
    $resultats = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($resultats as &$row) {
        if (!empty($row['stages_list'])) {
            $row['stages'] = json_decode($row['stages_list']);
        } else {
            $row['stages'] = [];
        }
        
        unset($row['stages_list']);
    }

    echo json_encode($resultats, JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Erreur SQL : " . $e->getMessage()]);
}
?>
