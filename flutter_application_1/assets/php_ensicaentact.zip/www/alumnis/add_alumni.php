<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = null;

if (isset($headers['X-Authorization'])) $authHeader = $headers['X-Authorization'];
elseif (isset($_SERVER['HTTP_X_AUTHORIZATION'])) $authHeader = $_SERVER['HTTP_X_AUTHORIZATION'];
elseif (isset($headers['Authorization'])) $authHeader = $headers['Authorization'];
elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
elseif (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];

$token = null;
if ($authHeader && preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    $token = $matches[1];
} elseif ($authHeader) {
    $token = $authHeader;
}

require_once "../jwt_utils.php"; 
$userData = null;
try {
    if(function_exists('verifyJWT')) $userData = verifyJWT($token);
} catch (Exception $e) { }

if (!$userData || (isset($userData['role']) && $userData['role'] !== 'admin')) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Accès refusé. Token invalide ou manquant.", "debug_token_recu" => $token]);
    exit();
}

require_once "../db.php"; 

$data = json_decode(file_get_contents("php://input"));
$idEditeur = $userData['id'] ?? $userData['id_user'] ?? 0;
$rawPassword = !empty($data->password) ? $data->password : "password";
$defaultPassword = password_hash($rawPassword, PASSWORD_BCRYPT);

if(!empty($data->nom) && !empty($data->prenom)) {
    try {
        $pdo->beginTransaction();

        $autorVal = !empty($data->autor) ? 1 : 0;
        $decedeVal = !empty($data->decede) ? 1 : 0;

        $stmtUser = $pdo->prepare("INSERT INTO UTILISATEUR (nom, prenom, email, role, password) VALUES (?, ?, ?, 'alumni', ?)");
        $stmtUser->execute([$data->nom, $data->prenom, $data->email ?? '', $defaultPassword]);
        $idUser = $pdo->lastInsertId();

        $stmtAlumni = $pdo->prepare("INSERT INTO ALUMNI (id_user, date_naissance, sexe, tel, decede, autor) VALUES (?, ?, ?, ?, ?, ?)");
        $stmtAlumni->execute([
            $idUser,
            !empty($data->dateNaissance) ? $data->dateNaissance : NULL,
            $data->sexe ?? 'I', 
            $data->tel ?? '',
            $decedeVal, 
            $autorVal
        ]);

        // LIEU TRAVAIL
        $ent = $data->entreprise ?? 'Non renseigné';
        $vil = $data->ville ?? 'Inconnue';
        $cp  = $data->code_postal ?? '';
        $pay = $data->pays ?? '';
        $lat = isset($data->latitude) ? $data->latitude : NULL;
        $lon = isset($data->longitude) ? $data->longitude : NULL;
        
        $stmtCheckLieu = $pdo->prepare("SELECT id_lieu FROM LIEU WHERE entreprise = ? AND ville = ? AND code_postal = ? AND pays = ? LIMIT 1");
        $stmtCheckLieu->execute([$ent, $vil, $cp, $pay]);
        $rowLieu = $stmtCheckLieu->fetch(PDO::FETCH_ASSOC);
        
        if ($rowLieu) {
            $idLieuTravail = $rowLieu['id_lieu'];
            if ($lat !== NULL && $lon !== NULL) {
                $stmtUpdateCoords = $pdo->prepare("UPDATE LIEU SET latitude = ?, longitude = ? WHERE id_lieu = ? AND latitude IS NULL");
                $stmtUpdateCoords->execute([$lat, $lon, $idLieuTravail]);
            }
        } else {
            $stmtLieu = $pdo->prepare("INSERT INTO LIEU (entreprise, ville, code_postal, pays, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE id_lieu=LAST_INSERT_ID(id_lieu)");
	    $stmtLieu->execute([$ent, $vil, $cp, $pay, $lat, $lon]);
            $idLieuTravail = $pdo->lastInsertId();
        }

        $stmtTravail = $pdo->prepare("INSERT INTO TRAVAIL (poste, description, id_user, id_lieu, date_debut) VALUES (?, ?, ?, ?, ?)");
        $stmtTravail->execute([
            $data->job ?? 'Alumni', $data->description ?? '', $idUser, $idLieuTravail, 
            !empty($data->debut) ? $data->debut : NULL
        ]);

        // PROMO
        $annee = $data->promo ?? date("Y");
        $filiere = $data->filiere ?? 'Général';
        $formation = $data->formation ?? 'FISE';
        
        $stmtPromoCheck = $pdo->prepare("SELECT id_promo FROM PROMO WHERE promo = ? AND filiere = ? AND formation = ? LIMIT 1");
        $stmtPromoCheck->execute([$annee, $filiere, $formation]);
        $promoRow = $stmtPromoCheck->fetch(PDO::FETCH_ASSOC);
        
        if ($promoRow) {
            $idPromo = $promoRow['id_promo'];
        } else {
            $stmtNewPromo = $pdo->prepare("INSERT INTO PROMO (promo, filiere, formation) VALUES (?, ?, ?)");
            $stmtNewPromo->execute([$annee, $filiere, $formation]);
            $idPromo = $pdo->lastInsertId();
        }

        // EDUCATION
        $stmtEdu = $pdo->prepare("INSERT INTO EDUCATION (id_user, id_promo, majeure, option_) VALUES (?, ?, ?, ?)");
        $stmtEdu->execute([$idUser, $idPromo, $data->majeure ?? '', $data->option ?? '']);

        // STAGES
        if (!empty($data->stages) && is_array($data->stages)) {
            $stmtCheckLieu = $pdo->prepare("SELECT id_lieu FROM LIEU WHERE entreprise = ? AND ville = ? AND code_postal = ? AND pays = ? LIMIT 1");
            $stmtInsertLieu = $pdo->prepare("INSERT INTO LIEU (entreprise, ville, code_postal, pays) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE id_lieu=LAST_INSERT_ID(id_lieu)");
            $stmtStage = $pdo->prepare("INSERT INTO STAGE (intitule, annee, id_user, id_lieu, entrepriseUniversite, description, date_debut, date_fin) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

            foreach ($data->stages as $stage) {
                // Lieu du stage
                $eS = $stage->entreprise ?? '';
                $vS = $stage->ville ?? '';
                $pS = $stage->pays ?? '';
                $cpS = $stage->code_postal ?? '';
                
                $stmtCheckLieu->execute([$eS, $vS, $cpS, $pS]);
                $ls = $stmtCheckLieu->fetch(PDO::FETCH_ASSOC);
                
                $stmtStage->execute([
                    $stage->intitule ?? 'Stage', $stage->annee ?? '3A', $idUser, $idLS,
                    $stage->type ?? 'E', $stage->description ?? '',
                    !empty($stage->debut) ? $stage->debut : NULL,
                    !empty($stage->fin) ? $stage->fin : NULL
                ]);
            }
        }

        // HISTORIQUE
        $desc = "Ajout de {$data->prenom} {$data->nom}";
	$pdo->prepare("INSERT INTO HISTORIQUE (id_editeur, id_alumni, action, description, date_action) VALUES (?, ?, 'AJOUT', ?, NOW())")
    ->execute([$idEditeur, $idUser, $desc]);

        $pdo->commit();
        echo json_encode(["status" => "success", "message" => "Utilisateur ajouté avec succès."]);

    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Erreur SQL : " . $e->getMessage()]);
    }
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Nom et Prénom obligatoires."]);
}
?>
