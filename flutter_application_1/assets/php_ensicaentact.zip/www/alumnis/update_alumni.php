<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = $headers['X-Authorization'] ?? $_SERVER['HTTP_X_AUTHORIZATION'] ?? $headers['Authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? null;
$token = $authHeader ? (preg_match('/Bearer\s(\S+)/', $authHeader, $matches) ? $matches[1] : $authHeader) : null;

require_once "../jwt_utils.php"; 
$userData = null;
try {
    if(function_exists('verifyJWT')) {
        $userData = verifyJWT($token);
    }
} catch (Exception $e) { }

if (!$userData || (isset($userData['role']) && $userData['role'] !== 'admin')) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Accès refusé. Token invalide ou manquant."]);
    exit();
}

require_once "../db.php";

$data = json_decode(file_get_contents("php://input"));
$idEditeur = $userData['id'] ?? $userData['id_user'] ?? 0;

if(!empty($data->id)) {
    try {
        $pdo->beginTransaction();
        $idUser = $data->id;

        $sqlOld = "SELECT 
                    u.nom, u.prenom, u.email, a.tel, a.autor, a.decede, a.date_naissance,
                    t.poste AS ancien_poste,
                    t.description AS ancienne_desc_poste,
                    t.date_debut AS ancien_debut_poste,
                    l.entreprise AS ancienne_entreprise,
                    l.ville AS ancienne_ville,
                    l.code_postal AS ancien_cp,
                    l.pays AS ancien_pays,
                    p.filiere AS ancienne_filiere,
                    p.promo AS ancienne_promo,
                    e.majeure AS ancienne_majeure,
                    e.option_ AS ancienne_option,
                    e.ddiplome AS ancien_diplome
                    FROM UTILISATEUR u
                    LEFT JOIN ALUMNI a ON u.id_user = a.id_user
                    LEFT JOIN TRAVAIL t ON u.id_user = t.id_user
                    LEFT JOIN LIEU l ON t.id_lieu = l.id_lieu
                    LEFT JOIN EDUCATION e ON u.id_user = e.id_user
                    LEFT JOIN PROMO p ON e.id_promo = p.id_promo
                    WHERE u.id_user = ?";
        
        $stmtUser = $pdo->prepare($sqlOld);
        $stmtUser->execute([$idUser]);
        $oldData = $stmtUser->fetch(PDO::FETCH_ASSOC);

        if($oldData) {
            $nouveauNom = $data->nom ?? $oldData['nom'];
            $nouveauPrenom = $data->prenom ?? $oldData['prenom'];
            $nouvelleDateNaiss = !empty($data->dateNaissance) ? $data->dateNaissance : ($oldData['date_naissance'] ?? NULL);
            $nouveauTel = $data->tel ?? $oldData['tel'];
            $nouvelEmail = $data->email ?? $oldData['email'];
            
            // Données Pro
            $nouveauPoste = $data->poste ?? $oldData['ancien_poste'] ?? 'En recherche';
            $nouvelleDescPoste = $data->description ?? $oldData['ancienne_desc_poste'] ?? '';
            $nouveauDebutPoste = !empty($data->debut) ? $data->debut : ($oldData['ancien_debut_poste'] ?? NULL);
            
            $nouvelleEntreprise = $data->entreprise ?? $oldData['ancienne_entreprise'] ?? 'Non renseigné';
            $nouvelleVille = $data->ville ?? $oldData['ancienne_ville'] ?? 'Inconnue';
            $nouveauCP = $data->code_postal ?? $oldData['ancien_cp'] ?? '';
            $nouveauPays = $data->pays ?? $oldData['ancien_pays'] ?? '';
            
            // Données Education
            $nouvelleFiliere = $data->filiere ?? $oldData['ancienne_filiere'] ?? 'Non renseignée';
            $nouvellePromo = !empty($data->promo) ? $data->promo : ($oldData['ancienne_promo'] ?? date('Y'));
            $nouvelleMajeure = $data->majeure ?? $oldData['ancienne_majeure'] ?? 'Non spécifiée';
            $nouvelleOption = $data->option ?? $oldData['ancienne_option'] ?? 'Non spécifiée';
            $nouveauDiplome = $data->diplome ?? $oldData['ancien_diplome'] ?? '';

            $nouveauAutor = isset($data->autor) ? $data->autor : ($oldData['autor'] ?? 0);
            $nouveauDecede = isset($data->decede) ? $data->decede : ($oldData['decede'] ?? 0);


            // UTILISATEUR & ALUMNI
            $stmtUpdUser = $pdo->prepare("UPDATE UTILISATEUR SET nom=?, prenom=?, email=? WHERE id_user=?");
            $stmtUpdUser->execute([$nouveauNom, $nouveauPrenom, $nouvelEmail, $idUser]);
            
            $stmtUpdAlumni = $pdo->prepare("UPDATE ALUMNI SET date_naissance=?, tel=?, autor=?, decede=? WHERE id_user=?");
            $stmtUpdAlumni->execute([$nouvelleDateNaiss, $nouveauTel, $nouveauAutor, $nouveauDecede, $idUser]);

            // TRAVAIL & LIEU 
            $lat = isset($data->latitude) ? $data->latitude : NULL;
            $lon = isset($data->longitude) ? $data->longitude : NULL;

            $stmtCheckLieu = $pdo->prepare("SELECT id_lieu FROM LIEU WHERE entreprise = ? AND ville = ? AND pays = ? LIMIT 1");
            $stmtCheckLieu->execute([$nouvelleEntreprise, $nouvelleVille, $nouveauPays]);
            $lieuExistant = $stmtCheckLieu->fetch(PDO::FETCH_ASSOC);

            if ($lieuExistant) {
                $idLieuTravail = $lieuExistant['id_lieu'];
                $stmtUpdateCoords = $pdo->prepare("UPDATE LIEU SET latitude = COALESCE(?, latitude), longitude = COALESCE(?, longitude), code_postal = NULLIF(?, '') WHERE id_lieu = ?");
                $stmtUpdateCoords->execute([$lat, $lon, $nouveauCP, $idLieuTravail]);
            } else {
                $stmtInsLieu = $pdo->prepare("INSERT INTO LIEU (entreprise, ville, code_postal, pays, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?)");
                $stmtInsLieu->execute([$nouvelleEntreprise, $nouvelleVille, $nouveauCP, $nouveauPays, $lat, $lon]);
                $idLieuTravail = $pdo->lastInsertId();
            }

            $stmtUpdTravail = $pdo->prepare("UPDATE TRAVAIL SET poste=?, description=?, date_debut=?, id_lieu=? WHERE id_user=?");
            $stmtUpdTravail->execute([$nouveauPoste, $nouvelleDescPoste, $nouveauDebutPoste, $idLieuTravail, $idUser]);

            // PROMO & EDUCATION
            $stmtPromo = $pdo->prepare("SELECT id_promo FROM PROMO WHERE promo = ? AND filiere = ? LIMIT 1");
            $stmtPromo->execute([$nouvellePromo, $nouvelleFiliere]);
            $promoRow = $stmtPromo->fetch(PDO::FETCH_ASSOC);
            
            if ($promoRow) {
                $idPromo = $promoRow['id_promo'];
            } else {
                $stmtNewPromo = $pdo->prepare("INSERT INTO PROMO (promo, filiere) VALUES (?, ?)");
                $stmtNewPromo->execute([$nouvellePromo, $nouvelleFiliere]);
                $idPromo = $pdo->lastInsertId();
            }
            
            $checkEdu = $pdo->prepare("SELECT id_education FROM EDUCATION WHERE id_user = ?");
            $checkEdu->execute([$idUser]);
            
            if ($checkEdu->fetch()) {
                 $pdo->prepare("UPDATE EDUCATION SET id_promo = ?, majeure = ?, option_ = ?, ddiplome = ? WHERE id_user = ?")
                     ->execute([$idPromo, $nouvelleMajeure, $nouvelleOption, $nouveauDiplome, $idUser]);
            } else {
                 $pdo->prepare("INSERT INTO EDUCATION (id_user, id_promo, majeure, option_, ddiplome) VALUES (?, ?, ?, ?, ?)")
                     ->execute([$idUser, $idPromo, $nouvelleMajeure, $nouvelleOption, $nouveauDiplome]);
            }

            // STAGES
            $stagesModifies = false;
            if (isset($data->stages) && is_array($data->stages)) {
                
                $stmtOldS = $pdo->prepare("SELECT s.intitule, s.annee, l.entreprise FROM STAGE s LEFT JOIN LIEU l ON s.id_lieu = l.id_lieu WHERE s.id_user = ? ORDER BY s.id_stage ASC");
                $stmtOldS->execute([$idUser]);
                $oldStages = $stmtOldS->fetchAll(PDO::FETCH_ASSOC);

                $oldStr = "";
                foreach($oldStages as $os) $oldStr .= $os['annee'] . $os['entreprise'] . $os['intitule'];

                $newStr = "";
                foreach($data->stages as $ns) $newStr .= ($ns->annee ?? '3A') . ($ns->entreprise ?? 'Non renseignée') . ($ns->intitule ?? 'Stage');

                if ($oldStr !== $newStr) {
                    $stagesModifies = true;
                }


                $pdo->prepare("DELETE FROM STAGE WHERE id_user = ?")->execute([$idUser]);

                $stmtCheckLieuStage = $pdo->prepare("SELECT id_lieu FROM LIEU WHERE entreprise = ? AND ville = ? AND pays = ? LIMIT 1");
                $stmtInsLieuStage = $pdo->prepare("INSERT INTO LIEU (entreprise, ville, code_postal, pays) VALUES (?, ?, ?, ?)");
                $stmtStage = $pdo->prepare("INSERT INTO STAGE (intitule, annee, id_user, id_lieu, entrepriseUniversite, description, date_debut, date_fin) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

                foreach ($data->stages as $stage) {
                    $ent = $stage->entreprise ?? 'Non renseignée';
                    $vil = $stage->ville ?? '';
                    $cpS = $stage->code_postal ?? '';
                    $pay = $stage->pays ?? '';
                    
                    $stmtCheckLieuStage->execute([$ent, $vil, $pay]);
                    $rowLieuS = $stmtCheckLieuStage->fetch(PDO::FETCH_ASSOC);

                    if ($rowLieuS) {
                        $idLieuStage = $rowLieuS['id_lieu'];
                    } else {
                        $stmtInsLieuStage->execute([$ent, $vil, $cpS, $pay]);
                        $idLieuStage = $pdo->lastInsertId();
                    }

                    $titre = $stage->intitule ?? 'Stage';
                    $annee = $stage->annee ?? '3A';
                    $desc = $stage->description ?? '';
                    $type = $stage->type ?? 'E';
                    $dDebut = !empty($stage->debut) ? $stage->debut : NULL;
                    $dFin = !empty($stage->fin) ? $stage->fin : NULL;

                    $stmtStage->execute([$titre, $annee, $idUser, $idLieuStage, $type, $desc, $dDebut, $dFin]);
                }
            }

            $changements = [];

            // Données personnelles
            if ($oldData['nom'] != $nouveauNom) {
                $changements[] = "Nom (" . ($oldData['nom'] ?: 'Vide') . " -> " . $nouveauNom . ")";
            }
            if ($oldData['prenom'] != $nouveauPrenom) {
                $changements[] = "Prénom (" . ($oldData['prenom'] ?: 'Vide') . " -> " . $nouveauPrenom . ")";
            }
            if ($oldData['tel'] != $nouveauTel) {
                $changements[] = "Téléphone (" . ($oldData['tel'] ?: 'Vide') . " -> " . $nouveauTel . ")";
            }
            if ($oldData['email'] != $nouvelEmail) {
                $changements[] = "Email (" . ($oldData['email'] ?: 'Vide') . " -> " . $nouvelEmail . ")";
            }

            // Données pro
            if (($oldData['ancien_poste'] ?? '') != $nouveauPoste) {
                $changements[] = "Poste (" . ($oldData['ancien_poste'] ?: 'Vide') . " -> " . $nouveauPoste . ")";
            }
            if (($oldData['ancienne_entreprise'] ?? '') != $nouvelleEntreprise) {
                $changements[] = "Entreprise (" . ($oldData['ancienne_entreprise'] ?: 'Vide') . " -> " . $nouvelleEntreprise . ")";
            }
            if (($oldData['ancienne_ville'] ?? '') != $nouvelleVille) {
                $changements[] = "Ville (" . ($oldData['ancienne_ville'] ?: 'Vide') . " -> " . $nouvelleVille . ")";
            }
            
            // Données scolaires
            if (($oldData['ancienne_filiere'] ?? '') != $nouvelleFiliere) {
                $changements[] = "Filière (" . ($oldData['ancienne_filiere'] ?: 'Vide') . " -> " . $nouvelleFiliere . ")";
            }
            if (($oldData['ancienne_promo'] ?? '') != $nouvellePromo) {
                $changements[] = "Promo (" . ($oldData['ancienne_promo'] ?: 'Vide') . " -> " . $nouvellePromo . ")";
            }

	if ($stagesModifies) {
                $changements[] = "Expériences/Stages mis à jour";
            }
            $descriptionAction = (count($changements) > 0) 
                ? implode(' | ', $changements) 
                : "Sauvegarde générale";
            
            $stmtLog = $pdo->prepare("INSERT INTO HISTORIQUE (id_editeur, id_alumni, action, description, date_action) VALUES (?, ?, 'MODIFICATION', ?, NOW())");
            $stmtLog->execute([$idEditeur, $idUser, $descriptionAction]);

            $pdo->commit();
            echo json_encode(["status" => "success", "message" => "Mis à jour"]);

        } else {
            echo json_encode(["status" => "error", "message" => "Utilisateur introuvable avec cet ID."]);
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        echo json_encode(["status" => "error", "message" => "Erreur SQL : " . $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "ID manquant pour la modification"]);
}
?>
