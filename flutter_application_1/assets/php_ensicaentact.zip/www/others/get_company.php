<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = null;

if (isset($headers['X-Authorization'])) $authHeader = $headers['X-Authorization'];
elseif (isset($_SERVER['HTTP_X_AUTHORIZATION'])) $authHeader = $_SERVER['HTTP_X_AUTHORIZATION'];
elseif (isset($headers['Authorization'])) $authHeader = $headers['Authorization'];
elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) $authHeader = $_SERVER['HTTP_AUTHORIZATION'];

$token = null;
if ($authHeader && preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    $token = $matches[1];
} elseif ($authHeader) {
    $token = $authHeader;
}

require_once "../jwt_utils.php"; 
$userData = null;
try {
    if(function_exists('verifyJWT')) $userData = verifyJWT($token);
} catch (Exception $e) { }

if (!$userData) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Access denied. Invalid or missing token."]);
    exit();
}

require_once "../db.php";

$sql = "SELECT 
            l.entreprise AS nom_entreprise, 
            l.ville,
            l.code_postal,
            l.pays,
            l.latitude,
            l.longitude,
            COUNT(t.id_user) AS nombre_alumni
        FROM TRAVAIL t
        JOIN LIEU l ON t.id_lieu = l.id_lieu
        WHERE l.entreprise IS NOT NULL AND l.entreprise != ''
        GROUP BY l.id_lieu, l.entreprise, l.ville,l.code_postal, l.pays, l.latitude, l.longitude
        ORDER BY nombre_alumni DESC";
try {
    $stmt = $pdo->query($sql);
    $resultats = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($resultats, JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Erreur SQL : " . $e->getMessage()]);
}
