<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
$authHeader = $headers['X-Authorization'] ?? $_SERVER['HTTP_X_AUTHORIZATION'] ?? $headers['Authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? null;
$token = $authHeader ? (preg_match('/Bearer\s(\S+)/', $authHeader, $matches) ? $matches[1] : $authHeader) : null;


require_once "../jwt_utils.php"; 
$userData = null;
try { if(function_exists('verifyJWT')) $userData = verifyJWT($token); } catch (Exception $e) { }

if (!$userData || (isset($userData['role']) && $userData['role'] !== 'admin')) {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Access denied."]);
    exit();
}

require_once "../db.php";


try {
    $sql = "SELECT 
                h.action, 
                h.description, 
                h.date_action, 
                u1.prenom AS prenom_editeur, 
                u1.nom AS nom_editeur,
                u2.prenom AS prenom_alumni, 
                u2.nom AS nom_alumni
            FROM HISTORIQUE h
            LEFT JOIN UTILISATEUR u1 ON h.id_editeur = u1.id_user
            LEFT JOIN UTILISATEUR u2 ON h.id_alumni = u2.id_user
            ORDER BY h.date_action DESC";
            
    $stmt = $pdo->query($sql);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database error: " . $e->getMessage()]);
}
?>
