<?php
function generateJWT($id, $role) {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));

    $payload = json_encode([
        'id' => $id,
        'role' => $role,
        'exp' => time() + (60 * 60 * 24)
    ]);
    $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));

    $secret = 'MA_PHRASE_SECRETE_TRES_COMPLIQUEE_2024'; 

    $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, $secret, true);
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

    return $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
}

function verifyJWT($token) {
    $secret = 'MA_PHRASE_SECRETE_TRES_COMPLIQUEE_2024';

    if (!$token) return false;

    $parts = explode('.', $token);
    if (count($parts) !== 3) return false;

    $header = $parts[0];
    $payload = $parts[1];
    $signatureProvided = $parts[2];

    $signatureCheck = hash_hmac('sha256', $header . "." . $payload, $secret, true);
    $base64UrlSignatureCheck = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signatureCheck));

    if ($base64UrlSignatureCheck === $signatureProvided) {
        $jsonPayload = base64_decode(str_replace(['-', '_'], ['+', '/'], $payload));
        return json_decode($jsonPayload, true);
    }
    return false;
}
?>
